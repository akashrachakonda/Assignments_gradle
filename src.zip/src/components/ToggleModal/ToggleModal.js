import React, { Component } from 'react';
import { MDBContainer, MDBBtn, MDBModal, MDBModalBody, MDBModalHeader, MDBModalFooter } from 'mdbreact';

class ToggleModal extends Component {
    constructor(props){
        super(props);

        
        console.log(this.props);
        console.log(this.state);
        this.state={
  
            isOpen: this.props.isOpen
            
          }
          console.log(this.state);

    }
    




toggle = () => {
  //let modalNumber = 'modal' + nr
    this.setState({
        isOpen:false
    })
   
}

render() {
    // console.log(this.state.isOpen);
    // console.log(this.props.isOpen);
    
  return (
    <MDBContainer>
    
     
      <MDBModal isOpen={this.state.isOpen} toggle={this.toggle} size="sm">
        <MDBModalHeader toggle={this.toggle}>MDBModal title</MDBModalHeader>
        <MDBModalBody>
          Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore
          magna aliqua.
        </MDBModalBody>
        <MDBModalFooter>
          <MDBBtn color="secondary" size="sm" onClick={this.toggle}>Close</MDBBtn>
          <MDBBtn color="primary" size="sm">Save changes</MDBBtn>
        </MDBModalFooter>
      </MDBModal>   
    
     
    </MDBContainer>
    );
  }
}

export default ToggleModal;