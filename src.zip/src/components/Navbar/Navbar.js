import React from 'react';
import { MDBNavbar, MDBNavbarBrand, MDBNavbarNav, MDBNavbarToggler, MDBCollapse, MDBNavItem, MDBNavLink, MDBContainer, MDBMask, MDBView,MDBIcon,MDBTooltip } from 'mdbreact';
import { BrowserRouter as Router } from 'react-router-dom';
import Offers from '../Offers_zone/Offers';
import Toggle from '../Toggle/Toggle'


import './Navbar.css';

class Navbar extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      collapse: false,
      isWideEnough: false,
    };
    this.onClick = this.onClick.bind(this);
  }

  onClick() {
    this.setState({
      collapse: !this.state.collapse,
    });
  }

  

  render() {
    return (
      <div>
    
     
            <MDBNavbar color="bg-primary" fixed="top" dark expand="md" scrolling transparent>
              <MDBNavbarBrand href="/" style={{padding:"0px",margin:"0px"}}>
               <img src="Logo1.png" style={{height:"80px",width:"80px"}}/>
              </MDBNavbarBrand>
              {!this.state.isWideEnough && <MDBNavbarToggler onClick={this.onClick} />}
              <MDBCollapse isOpen={this.state.collapse} navbar style={{paddingLeft:"20px"}}>
                <MDBNavbarNav left>
                  <MDBNavItem active>
                    <MDBNavLink to="#">Home</MDBNavLink>
                  </MDBNavItem>
                  <MDBNavItem>
                    <MDBNavLink to="#">Link</MDBNavLink>
                  </MDBNavItem>
                  </MDBNavbarNav>
                  <MDBNavbarNav right>


                  <MDBNavItem style={{color:"white",paddingTop:"7px",paddingRight:"30px"}}>

                    <Toggle  switchToggle={this.props.switchToggle} handleSwitchChange={this.props.handleSwitchChange}/>
                  </MDBNavItem>

                  <MDBNavItem >
                
              
                  <MDBIcon far icon="bell" style={{color:"white",paddingTop:"10px",paddingRight:"30px"}} title="Notifications"/>
           
                
                  </MDBNavItem>
               
                  <MDBNavItem >
                  <MDBIcon far icon="user-circle"  style={{color:"white",paddingTop:"10px",paddingRight:"20px"}} title="User Profile" />
                  </MDBNavItem>
                  <MDBNavItem >
                    <MDBNavLink to="#">Logout</MDBNavLink>
                  </MDBNavItem>
                  </MDBNavbarNav>

               
              </MDBCollapse>
            </MDBNavbar>


          
      </div>
    );
  }
}

export default Navbar;