

export default function AddNewOffer(payload){
    
    return {
        type:"ADD_NEW_OFFER",
        payload
    }
}